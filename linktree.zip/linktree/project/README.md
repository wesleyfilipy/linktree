# TinyLink - URL Shortener

TinyLink is a modern URL shortener service built with Next.js, offering fast redirects, analytics tracking, and QR code generation.

## Features

- ⚡ **URL Shortening** - Create short, memorable links instantly
- 📊 **Analytics** - Track clicks and performance metrics for your links
- 📱 **QR Codes** - Generate QR codes for easy mobile sharing
- 🛡️ **Link Validation** - Automatic protection against malicious and spam links
- 🚀 **Fast Redirects** - Optimized for speed and SEO

## Tech Stack

- **Framework**: [Next.js](https://nextjs.org/)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **UI Components**: [shadcn/ui](https://ui.shadcn.com/)
- **Database**: [SQLite](https://www.sqlite.org/) (via better-sqlite3)
- **Deployment**: [Cloudflare Pages](https://pages.cloudflare.com/)

## Getting Started

### Prerequisites

- Node.js 18+ and npm

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/tinylink.git
   cd tinylink
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the project root:
   ```
   NEXT_PUBLIC_BASE_URL=http://localhost:3000
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

5. Open [http://localhost:3000](http://localhost:3000) in your browser to see the application.

## Deployment to Cloudflare Pages

### Setup

1. Push your repository to GitHub
2. Log in to Cloudflare Dashboard
3. Go to Pages > Create a project > Connect to Git
4. Select your repository
5. Configure with these build settings:
   - Framework preset: Next.js
   - Build command: npm run build
   - Build output directory: .next
   - Environment variables:
     - NODE_VERSION: 18
     - NEXT_PUBLIC_BASE_URL: https://your-domain.pages.dev (or your custom domain)

### Important Notes for Cloudflare Deployment

- Make sure to update the `NEXT_PUBLIC_BASE_URL` environment variable to match your Cloudflare Pages domain
- For SQLite to work properly, we're using a custom build to ensure the database is writable in a serverless environment
- The data directory needs to be available in the production environment for database persistence

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [Lucide Icons](https://lucide.dev/)
- [shadcn/ui](https://ui.shadcn.com/)
- [Next.js](https://nextjs.org/)
- [Tailwind CSS](https://tailwindcss.com/) 