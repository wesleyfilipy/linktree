'use client';

interface AdBannerProps {
  position: 'top' | 'middle' | 'bottom';
}

export function AdBanner({ position }: AdBannerProps) {
  const getAdContent = () => {
    switch (position) {
      case 'top':
        return {
          title: 'Boost Your Business',
          description: 'Advertise with us and reach thousands of users daily',
          cta: 'Learn More'
        };
      case 'middle':
        return {
          title: 'Premium Features',
          description: 'Upgrade to get advanced analytics and custom domains',
          cta: 'Upgrade Now'
        };
      case 'bottom':
        return {
          title: 'Start Your Campaign',
          description: 'Get your message in front of our engaged audience',
          cta: 'Advertise Here'
        };
      default:
        return {
          title: 'Advertisement',
          description: 'Your ad could be here',
          cta: 'Contact Us'
        };
    }
  };

  const adContent = getAdContent();

  return (
    <div className="w-full max-w-4xl mx-auto my-8">
      <div className="bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-2">
              {adContent.title}
            </h3>
            <p className="text-blue-700 dark:text-blue-200 text-sm">
              {adContent.description}
            </p>
          </div>
          <div className="ml-4">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
              {adContent.cta}
            </button>
          </div>
        </div>
        <div className="text-xs text-blue-600 dark:text-blue-400 mt-2">
          Advertisement
        </div>
      </div>
    </div>
  );
}