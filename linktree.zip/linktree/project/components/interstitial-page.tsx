'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ExternalLink, Clock } from 'lucide-react';
import { AdBanner } from '@/components/ad-banner';

interface InterstitialPageProps {
  url: string;
}

export function InterstitialPage({ url }: InterstitialPageProps) {
  const [countdown, setCountdown] = useState(3);
  const router = useRouter();

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          window.location.href = url;
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [url]);

  const skipWait = () => {
    window.location.href = url;
  };

  const progress = ((3 - countdown) / 3) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <AdBanner position="top" />
        
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center mb-4">
              <Clock className="w-12 h-12 text-blue-600" />
            </div>
            <CardTitle className="text-2xl">Redirecting you in {countdown}...</CardTitle>
            <CardDescription>
              You will be redirected to your destination shortly
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                Destination:
              </p>
              <p className="text-blue-600 dark:text-blue-400 font-mono text-sm break-all">
                {url}
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Redirecting...</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
            
            <div className="flex flex-col space-y-2">
              <Button onClick={skipWait} className="w-full">
                <ExternalLink className="w-4 h-4 mr-2" />
                Skip Wait & Continue
              </Button>
              <Button variant="outline" onClick={() => router.back()} className="w-full">
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}