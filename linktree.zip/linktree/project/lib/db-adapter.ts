// Database adapter for handling different environments

import { getDbImplementation, UrlStorage } from './cloudflare-db';
import * as sqliteDb from './db';

// Check if we're running on Cloudflare Pages
const isCloudflare = process.env.CF_PAGES === '1';

// Export the right implementation based on environment
export const storeUrl = isCloudflare 
  ? getDbImplementation().storeUrl 
  : sqliteDb.storeUrl;

export const getUrlBySlug = isCloudflare 
  ? getDbImplementation().getUrlBySlug 
  : sqliteDb.getUrlBySlug;

export const incrementClicks = isCloudflare 
  ? getDbImplementation().incrementClicks 
  : sqliteDb.incrementClicks;

export const slugExists = isCloudflare 
  ? getDbImplementation().slugExists 
  : sqliteDb.slugExists;

export const getAllUrls = isCloudflare 
  ? getDbImplementation().getAllUrls 
  : sqliteDb.getAllUrls; 