import Database from 'better-sqlite3';
import { join } from 'path';
import fs from 'fs';

// Ensure the data directory exists
const dataDir = join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize database
const dbPath = join(dataDir, 'urls.db');
const db = new Database(dbPath);

// Create tables if they don't exist
db.exec(`
  CREATE TABLE IF NOT EXISTS urls (
    slug TEXT PRIMARY KEY,
    originalUrl TEXT NOT NULL,
    clicks INTEGER DEFAULT 0,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

// Helper functions for URL operations
export function storeUrl(slug: string, url: string) {
  const stmt = db.prepare('INSERT INTO urls (slug, originalUrl) VALUES (?, ?)');
  stmt.run(slug, url);
}

export function getUrlBySlug(slug: string) {
  const stmt = db.prepare('SELECT * FROM urls WHERE slug = ?');
  return stmt.get(slug);
}

export function incrementClicks(slug: string) {
  const stmt = db.prepare('UPDATE urls SET clicks = clicks + 1 WHERE slug = ?');
  stmt.run(slug);
}

export function slugExists(slug: string) {
  const stmt = db.prepare('SELECT COUNT(*) as count FROM urls WHERE slug = ?');
  const result = stmt.get(slug) as { count: number };
  return result.count > 0;
}

export function getAllUrls() {
  const stmt = db.prepare('SELECT * FROM urls ORDER BY createdAt DESC');
  return stmt.all();
} 