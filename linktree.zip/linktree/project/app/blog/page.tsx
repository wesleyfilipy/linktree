import { Metadata } from 'next';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CalendarDays, Clock, User } from 'lucide-react';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { AdBanner } from '@/components/ad-banner';

export const metadata: Metadata = {
  title: 'Blog - TinyLink URL Shortener Tips & Guides',
  description: 'Learn how to use URL shorteners effectively for marketing, social media, and business growth. Expert tips and strategies.',
  keywords: 'URL shortener blog, link shortening tips, marketing strategies, social media, digital marketing',
};

const blogPosts = [
  {
    id: 1,
    title: 'The Ultimate Guide to URL Shortening for Marketing',
    slug: 'ultimate-guide-url-shortening-marketing',
    excerpt: 'Discover how to leverage URL shorteners to boost your marketing campaigns, track performance, and improve user experience.',
    image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Marketing',
    author: 'Sarah Johnson',
    publishedAt: '2024-01-15',
    readTime: '8 min read'
  },
  {
    id: 2,
    title: 'How to Track Link Performance with Analytics',
    slug: 'track-link-performance-analytics',
    excerpt: 'Learn how to use link analytics to measure campaign success, understand your audience, and optimize your marketing strategy.',
    image: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Analytics',
    author: 'Mike Chen',
    publishedAt: '2024-01-12',
    readTime: '6 min read'
  },
  {
    id: 3,
    title: 'Best Practices for Social Media Link Sharing',
    slug: 'social-media-link-sharing-best-practices',
    excerpt: 'Optimize your social media presence with effective link sharing strategies that drive engagement and conversions.',
    image: 'https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Social Media',
    author: 'Emma Davis',
    publishedAt: '2024-01-10',
    readTime: '7 min read'
  },
  {
    id: 4,
    title: 'QR Codes vs Short Links: Which is Better?',
    slug: 'qr-codes-vs-short-links-comparison',
    excerpt: 'Compare QR codes and short links to determine the best option for your marketing campaigns and user experience.',
    image: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Technology',
    author: 'David Wilson',
    publishedAt: '2024-01-08',
    readTime: '5 min read'
  },
  {
    id: 5,
    title: 'Email Marketing with Short Links: A Complete Guide',
    slug: 'email-marketing-short-links-guide',
    excerpt: 'Maximize your email marketing effectiveness with short links that track engagement and improve deliverability.',
    image: 'https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Email Marketing',
    author: 'Lisa Anderson',
    publishedAt: '2024-01-05',
    readTime: '9 min read'
  },
  {
    id: 6,
    title: 'Brand Safety: Protecting Your Links from Abuse',
    slug: 'brand-safety-protecting-links-abuse',
    excerpt: 'Learn how to protect your brand reputation by preventing link abuse and maintaining trust with your audience.',
    image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Security',
    author: 'Tom Rodriguez',
    publishedAt: '2024-01-03',
    readTime: '6 min read'
  }
];

const categories = ['All', 'Marketing', 'Analytics', 'Social Media', 'Technology', 'Email Marketing', 'Security'];

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <AdBanner position="top" />
        
        {/* Hero Section */}
        <section className="text-center py-12">
          <h1 className="text-4xl font-bold mb-4">
            Link Shortening Blog
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Expert tips, strategies, and insights to help you master URL shortening for marketing success.
          </p>
        </section>

        {/* Categories */}
        <section className="mb-12">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <Badge key={category} variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                {category}
              </Badge>
            ))}
          </div>
        </section>

        <AdBanner position="middle" />

        {/* Blog Grid */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <Card key={post.id} className="hover:shadow-lg transition-shadow overflow-hidden">
              <div className="aspect-video overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{post.category}</Badge>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="w-4 h-4 mr-1" />
                    {post.readTime}
                  </div>
                </div>
                <CardTitle className="text-xl hover:text-blue-600 transition-colors">
                  <Link href={`/blog/${post.slug}`}>
                    {post.title}
                  </Link>
                </CardTitle>
                <CardDescription>
                  {post.excerpt}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center">
                    <User className="w-4 h-4 mr-1" />
                    {post.author}
                  </div>
                  <div className="flex items-center">
                    <CalendarDays className="w-4 h-4 mr-1" />
                    {new Date(post.publishedAt).toLocaleDateString()}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </section>

        <AdBanner position="bottom" />
      </main>

      <Footer />
    </div>
  );
}