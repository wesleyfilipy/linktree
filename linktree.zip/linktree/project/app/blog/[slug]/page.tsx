import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { CalendarDays, Clock, User, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { AdBanner } from '@/components/ad-banner';
import Link from 'next/link';

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  image: string;
  category: string;
  author: string;
  publishedAt: string;
  readTime: string;
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: 'The Ultimate Guide to URL Shortening for Marketing',
    slug: 'ultimate-guide-url-shortening-marketing',
    excerpt: 'Discover how to leverage URL shorteners to boost your marketing campaigns, track performance, and improve user experience.',
    image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=1200',
    category: 'Marketing',
    author: 'Sarah Johnson',
    publishedAt: '2024-01-15',
    readTime: '8 min read',
    content: `
      <p>URL shortening has become an essential tool in modern digital marketing. Whether you're running social media campaigns, email marketing, or paid advertising, short links provide numerous benefits that can significantly impact your marketing success.</p>

      <h2>Why URL Shortening Matters in Marketing</h2>
      <p>Long URLs can be unwieldy and unprofessional-looking in marketing materials. They take up valuable character space in social media posts, can break in emails, and are difficult to remember. Short URLs solve these problems while providing additional benefits:</p>

      <ul>
        <li>Better user experience with clean, professional links</li>
        <li>Detailed analytics and tracking capabilities</li>
        <li>Increased click-through rates</li>
        <li>Brand consistency with custom domains</li>
        <li>A/B testing opportunities</li>
      </ul>

      <h2>Best Practices for Marketing with Short Links</h2>
      <p>To maximize the effectiveness of your short links in marketing campaigns, follow these proven strategies:</p>

      <h3>1. Use Descriptive Custom Slugs</h3>
      <p>Instead of random characters, create custom slugs that give users an idea of what they'll find. For example, use "summer-sale-2024" instead of "a3d8Kf2".</p>

      <h3>2. Track Everything</h3>
      <p>Take advantage of analytics to understand which campaigns perform best. Monitor click-through rates, geographic data, and referrer sources to optimize your strategy.</p>

      <h3>3. Maintain Brand Consistency</h3>
      <p>Use a consistent domain and naming convention across all your campaigns to build brand recognition and trust.</p>

      <h2>Common Mistakes to Avoid</h2>
      <p>Many marketers make these critical errors when using URL shorteners:</p>

      <ul>
        <li>Not customizing slugs for brand consistency</li>
        <li>Ignoring analytics data</li>
        <li>Using different shorteners for different campaigns</li>
        <li>Not testing links before launching campaigns</li>
      </ul>

      <h2>Conclusion</h2>
      <p>URL shortening is more than just making links shorter – it's about creating a better user experience, tracking performance, and building brand consistency. By following these best practices, you'll be able to maximize the impact of your marketing campaigns.</p>
    `
  },
  {
    id: 2,
    title: 'How to Track Link Performance with Analytics',
    slug: 'track-link-performance-analytics',
    excerpt: 'Learn how to use link analytics to measure campaign success, understand your audience, and optimize your marketing strategy.',
    image: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg?auto=compress&cs=tinysrgb&w=1200',
    category: 'Analytics',
    author: 'Mike Chen',
    publishedAt: '2024-01-12',
    readTime: '6 min read',
    content: `
      <p>Understanding how your links perform is crucial for marketing success. Link analytics provide insights that help you make data-driven decisions and optimize your campaigns for better results.</p>

      <h2>Key Metrics to Track</h2>
      <p>When analyzing your link performance, focus on these essential metrics:</p>

      <h3>Click-Through Rate (CTR)</h3>
      <p>The percentage of people who click your link after seeing it. A higher CTR indicates more engaging content and effective placement.</p>

      <h3>Geographic Data</h3>
      <p>Understanding where your clicks come from helps you tailor content for specific regions and optimize posting times for different time zones.</p>

      <h3>Referrer Sources</h3>
      <p>Knowing which platforms drive the most traffic helps you focus your efforts on the most effective channels.</p>

      <h3>Device Information</h3>
      <p>Mobile vs. desktop usage patterns can inform your content strategy and help you optimize for the right platforms.</p>

      <h2>Setting Up Tracking</h2>
      <p>To get the most from your link analytics, set up proper tracking from the beginning:</p>

      <ol>
        <li>Use consistent naming conventions for your links</li>
        <li>Create separate links for different campaigns</li>
        <li>Set up regular reporting schedules</li>
        <li>Define success metrics before launching campaigns</li>
      </ol>

      <h2>Interpreting Your Data</h2>
      <p>Raw data is only useful if you can interpret it correctly. Here's how to make sense of your analytics:</p>

      <ul>
        <li>Compare performance across different channels</li>
        <li>Look for patterns in timing and engagement</li>
        <li>Identify your top-performing content types</li>
        <li>Track trends over time to spot opportunities</li>
      </ul>

      <h2>Taking Action on Insights</h2>
      <p>The real value of analytics comes from acting on your insights. Use your data to:</p>

      <ul>
        <li>Optimize posting times and frequencies</li>
        <li>Refine your content strategy</li>
        <li>Allocate budget to top-performing channels</li>
        <li>Identify and fix underperforming campaigns</li>
      </ul>

      <h2>Conclusion</h2>
      <p>Link analytics are a powerful tool for understanding your audience and optimizing your marketing efforts. By tracking the right metrics and acting on your insights, you can significantly improve your campaign performance and ROI.</p>
    `
  }
];

interface PageProps {
  params: { slug: string };
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const post = blogPosts.find(p => p.slug === params.slug);
  
  if (!post) {
    return {
      title: 'Post Not Found',
    };
  }

  return {
    title: `${post.title} - TinyLink Blog`,
    description: post.excerpt,
    keywords: `${post.category.toLowerCase()}, URL shortener, ${post.title.toLowerCase()}`,
    authors: [{ name: post.author }],
    openGraph: {
      title: post.title,
      description: post.excerpt,
      images: [{ url: post.image }],
      type: 'article',
      publishedTime: post.publishedAt,
      authors: [post.author],
    },
    twitter: {
      card: 'summary_large_image',
      title: post.title,
      description: post.excerpt,
      images: [post.image],
    },
  };
}

export default function BlogPost({ params }: PageProps) {
  const post = blogPosts.find(p => p.slug === params.slug);

  if (!post) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <AdBanner position="top" />
        
        <article className="max-w-4xl mx-auto">
          <div className="mb-8">
            <Link href="/blog">
              <Button variant="ghost" className="mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Blog
              </Button>
            </Link>
            
            <div className="aspect-video mb-6 overflow-hidden rounded-lg">
              <img 
                src={post.image} 
                alt={post.title}
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="flex items-center gap-4 mb-4">
              <Badge variant="secondary">{post.category}</Badge>
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="w-4 h-4 mr-1" />
                {post.readTime}
              </div>
            </div>
            
            <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
            
            <div className="flex items-center gap-6 text-sm text-muted-foreground mb-8">
              <div className="flex items-center">
                <User className="w-4 h-4 mr-1" />
                {post.author}
              </div>
              <div className="flex items-center">
                <CalendarDays className="w-4 h-4 mr-1" />
                {new Date(post.publishedAt).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            </div>
          </div>
          
          <AdBanner position="middle" />
          
          <div className="prose prose-lg max-w-none dark:prose-invert">
            <div dangerouslySetInnerHTML={{ __html: post.content }} />
          </div>
          
          <div className="mt-12 pt-8 border-t">
            <h3 className="text-xl font-semibold mb-4">About the Author</h3>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                {post.author.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <p className="font-medium">{post.author}</p>
                <p className="text-muted-foreground">Digital Marketing Expert</p>
              </div>
            </div>
          </div>
        </article>
        
        <AdBanner position="bottom" />
      </main>
      
      <Footer />
    </div>
  );
}