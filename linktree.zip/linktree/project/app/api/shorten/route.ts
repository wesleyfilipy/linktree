import { NextRequest, NextResponse } from 'next/server';
import { storeUrl, getUrlBySlug, slugExists } from '@/lib/db-adapter';

interface ShortenRequest {
  url: string;
  customSlug?: string;
}

function generateSlug(length = 6): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function isValidUrl(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}

function isMaliciousUrl(url: string): boolean {
  const maliciousDomains = [
    'bit.ly/spam',
    'malware.com',
    'phishing.net',
    // Add more malicious domains as needed
  ];
  
  return maliciousDomains.some(domain => url.includes(domain));
}

export async function POST(request: NextRequest) {
  try {
    const { url, customSlug }: ShortenRequest = await request.json();

    // Validate URL
    if (!url || !isValidUrl(url)) {
      return NextResponse.json(
        { error: 'Invalid URL provided' },
        { status: 400 }
      );
    }

    // Check for malicious URLs
    if (isMaliciousUrl(url)) {
      return NextResponse.json(
        { error: 'URL not allowed' },
        { status: 400 }
      );
    }

    // Generate or use custom slug
    let slug = customSlug || generateSlug();

    // Check if custom slug already exists
    if (slugExists(slug)) {
      if (customSlug) {
        return NextResponse.json(
          { error: 'Custom slug already exists' },
          { status: 409 }
        );
      } else {
        // Keep generating new slugs until we find an unused one
        do {
          slug = generateSlug();
        } while (slugExists(slug));
      }
    }

    // Store URL in database
    storeUrl(slug, url);

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
    const shortUrl = `${baseUrl}/${slug}`;

    return NextResponse.json({
      shortUrl,
      slug,
      originalUrl: url
    });

  } catch (error) {
    console.error('Error shortening URL:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const slug = searchParams.get('slug');

  if (!slug) {
    return NextResponse.json(
      { error: 'Slug parameter required' },
      { status: 400 }
    );
  }

  const urlData = getUrlBySlug(slug);
  if (!urlData) {
    return NextResponse.json(
      { error: 'URL not found' },
      { status: 404 }
    );
  }

  return NextResponse.json({
    slug,
    url: urlData.originalUrl,
    clicks: urlData.clicks,
    createdAt: urlData.createdAt
  });
}