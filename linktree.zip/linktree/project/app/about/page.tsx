import { Metadata } from 'next';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, Users, Zap, Shield, Globe, BarChart3 } from 'lucide-react';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { AdBanner } from '@/components/ad-banner';

export const metadata: Metadata = {
  title: 'About Us - TinyLink URL Shortener',
  description: 'Learn about TinyLink, our mission to make URL shortening simple and powerful, and how we help businesses and individuals track their links.',
};

export default function AboutPage() {
  const features = [
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Our global CDN ensures your links redirect instantly, anywhere in the world.'
    },
    {
      icon: BarChart3,
      title: 'Detailed Analytics',
      description: 'Get comprehensive insights into your link performance with real-time analytics.'
    },
    {
      icon: Shield,
      title: 'Security First',
      description: 'Advanced malware detection and link validation keep your users safe.'
    },
    {
      icon: Globe,
      title: 'Global Reach',
      description: 'Serve users worldwide with our distributed infrastructure.'
    },
    {
      icon: Users,
      title: 'User Focused',
      description: 'Built with user experience in mind, making complex features simple.'
    },
    {
      icon: Target,
      title: 'Marketing Ready',
      description: 'Perfect for campaigns, social media, and professional communications.'
    }
  ];

  const team = [
    {
      name: 'Sarah Johnson',
      role: 'CEO & Founder',
      bio: 'Former tech executive with 15+ years in digital marketing and SaaS platforms.',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Mike Chen',
      role: 'CTO',
      bio: 'Full-stack engineer specializing in scalable web applications and data analytics.',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Emma Davis',
      role: 'Head of Marketing',
      bio: 'Digital marketing expert with a passion for growth hacking and user acquisition.',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'David Wilson',
      role: 'Lead Developer',
      bio: 'Senior software engineer focused on performance optimization and user experience.',
      image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <AdBanner position="top" />
        
        {/* Hero Section */}
        <section className="text-center py-16">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            About TinyLink
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            We're on a mission to make URL shortening simple, powerful, and accessible to everyone. 
            From individual users to enterprise teams, we provide the tools you need to track, 
            analyze, and optimize your links.
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            <Badge variant="secondary" className="text-sm">Founded in 2023</Badge>
            <Badge variant="secondary" className="text-sm">10K+ Users</Badge>
            <Badge variant="secondary" className="text-sm">1M+ Links Created</Badge>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground mb-6">
                In today's digital world, every click matters. We believe that understanding your audience 
                and optimizing your content should be simple, not complicated by complex analytics tools 
                or unreliable link shorteners.
              </p>
              <p className="text-lg text-muted-foreground mb-6">
                That's why we built TinyLink - to provide a fast, reliable, and feature-rich URL shortening 
                service that gives you the insights you need to succeed online.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">99.9%</div>
                  <div className="text-sm text-muted-foreground">Uptime</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-2">&lt;100ms</div>
                  <div className="text-sm text-muted-foreground">Response Time</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/3184287/pexels-photo-3184287.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Team working together"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </section>

        <AdBanner position="middle" />

        {/* Features Section */}
        <section className="py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Makes Us Different</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We've built TinyLink from the ground up with performance, security, and user experience as our top priorities.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <feature.icon className="w-12 h-12 text-blue-600 mb-4" />
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We're a passionate team of developers, designers, and marketers dedicated to building the best URL shortening service.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-24 h-24 rounded-full mx-auto mb-4 overflow-hidden">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardTitle className="text-lg">{member.name}</CardTitle>
                  <CardDescription className="text-blue-600 font-medium">{member.role}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do at TinyLink.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Privacy First</h3>
              <p className="text-muted-foreground">
                We protect your data and respect your privacy. Your information is never sold or shared without permission.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">User-Centric</h3>
              <p className="text-muted-foreground">
                Every feature we build is designed with our users in mind. We listen to feedback and continuously improve.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Excellence</h3>
              <p className="text-muted-foreground">
                We strive for excellence in everything we do, from code quality to customer support.
              </p>
            </div>
          </div>
        </section>

        <AdBanner position="bottom" />
      </main>
      
      <Footer />
    </div>
  );
}