import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ThemeProvider } from '@/components/theme-provider';
import { CookieConsent } from '@/components/cookie-consent';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'TinyLink - URL Shortener with Analytics',
  description: 'Free URL shortener with advanced analytics, QR codes, and tracking. Create short links for social media, email campaigns, and marketing.',
  keywords: 'URL shortener, link shortener, analytics, QR codes, tracking, marketing',
  authors: [{ name: 'TinyLink Team' }],
  creator: 'TinyLink',
  publisher: 'TinyLink',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://tinylink.com'),
  alternates: {
    canonical: '/',
  },
  openGraph: {
    title: 'TinyLink - URL Shortener with Analytics',
    description: 'Free URL shortener with advanced analytics, QR codes, and tracking. Create short links for social media, email campaigns, and marketing.',
    url: 'https://tinylink.com',
    siteName: 'TinyLink',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'TinyLink URL Shortener',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'TinyLink - URL Shortener with Analytics',
    description: 'Free URL shortener with advanced analytics, QR codes, and tracking.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-site-verification-code',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="canonical" href="https://tinylink.com" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'WebApplication',
              name: 'TinyLink',
              description: 'Free URL shortener with advanced analytics, QR codes, and tracking.',
              url: 'https://tinylink.com',
              applicationCategory: 'WebApplication',
              operatingSystem: 'All',
              offers: {
                '@type': 'Offer',
                price: '0',
                priceCurrency: 'USD',
              },
              aggregateRating: {
                '@type': 'AggregateRating',
                ratingValue: '4.8',
                reviewCount: '1250',
              },
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <CookieConsent />
        </ThemeProvider>
      </body>
    </html>
  );
}