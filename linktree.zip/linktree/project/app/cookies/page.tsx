import { Metadata } from 'next';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { AdBanner } from '@/components/ad-banner';

export const metadata: Metadata = {
  title: 'Cookies Policy - TinyLink',
  description: 'Learn about how we use cookies and similar technologies to enhance your experience on TinyLink.',
};

export default function CookiesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <AdBanner position="top" />
        
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Cookies Policy</h1>
          
          <div className="prose prose-lg max-w-none dark:prose-invert">
            <p className="text-muted-foreground mb-8">
              <strong>Effective Date:</strong> January 1, 2024<br />
              <strong>Last Updated:</strong> January 1, 2024
            </p>

            <h2>What Are Cookies?</h2>
            <p>
              Cookies are small text files that are placed on your computer or mobile device when you visit our website. They are widely used to make websites work more efficiently and to provide information to website owners.
            </p>

            <h2>How We Use Cookies</h2>
            <p>
              TinyLink uses cookies to enhance your experience on our website. We use cookies for the following purposes:
            </p>

            <h3>Essential Cookies</h3>
            <p>
              These cookies are necessary for the website to function properly. They enable core functionality such as security, network management, and accessibility.
            </p>
            <ul>
              <li>Session management</li>
              <li>Authentication</li>
              <li>Security features</li>
              <li>Load balancing</li>
            </ul>

            <h3>Analytics Cookies</h3>
            <p>
              We use analytics cookies to understand how visitors use our website. This helps us improve our services and user experience.
            </p>
            <ul>
              <li>Google Analytics</li>
              <li>Page view tracking</li>
              <li>User behavior analysis</li>
              <li>Performance monitoring</li>
            </ul>

            <h3>Advertising Cookies</h3>
            <p>
              We use Google AdSense to display advertisements on our website. These cookies help us show you relevant ads based on your interests.
            </p>
            <ul>
              <li>Google AdSense</li>
              <li>Interest-based advertising</li>
              <li>Ad performance tracking</li>
              <li>Remarketing campaigns</li>
            </ul>

            <h3>Preference Cookies</h3>
            <p>
              These cookies remember your preferences and settings to provide you with a personalized experience.
            </p>
            <ul>
              <li>Language preferences</li>
              <li>Theme settings (dark/light mode)</li>
              <li>Layout preferences</li>
              <li>Cookie consent choices</li>
            </ul>

            <h2>Third-Party Cookies</h2>
            <p>
              We may also use third-party cookies from trusted partners to enhance our services:
            </p>

            <h3>Google Services</h3>
            <ul>
              <li><strong>Google Analytics:</strong> Helps us understand website usage and improve our services</li>
              <li><strong>Google AdSense:</strong> Displays relevant advertisements</li>
              <li><strong>Google Fonts:</strong> Provides web fonts for better typography</li>
            </ul>

            <h3>Social Media</h3>
            <ul>
              <li><strong>Social Media Buttons:</strong> Allow you to share content on social platforms</li>
              <li><strong>Embedded Content:</strong> Enable display of social media content</li>
            </ul>

            <h2>Managing Cookies</h2>
            <p>
              You have several options for managing cookies:
            </p>

            <h3>Cookie Consent</h3>
            <p>
              When you first visit our website, you'll see a cookie consent banner. You can choose to accept or decline non-essential cookies.
            </p>

            <h3>Browser Settings</h3>
            <p>
              You can control cookies through your browser settings. Most browsers allow you to:
            </p>
            <ul>
              <li>Block all cookies</li>
              <li>Block third-party cookies</li>
              <li>Delete existing cookies</li>
              <li>Receive notifications when cookies are being set</li>
            </ul>

            <h3>Opt-Out Tools</h3>
            <p>
              You can opt out of specific tracking services:
            </p>
            <ul>
              <li><strong>Google Analytics:</strong> Use the <a href="https://tools.google.com/dlpage/gaoptout" target=\"_blank" rel="noopener noreferrer">Google Analytics Opt-out Browser Add-on</a></li>
              <li><strong>Google Ads:</strong> Visit <a href="https://adssettings.google.com/" target=\"_blank" rel="noopener noreferrer">Google Ads Settings</a></li>
            </ul>

            <h2>Cookie Retention</h2>
            <p>
              Different cookies have different retention periods:
            </p>
            <ul>
              <li><strong>Session Cookies:</strong> Deleted when you close your browser</li>
              <li><strong>Persistent Cookies:</strong> Remain on your device for a specified period or until manually deleted</li>
              <li><strong>Analytics Cookies:</strong> Typically expire after 2 years</li>
              <li><strong>Advertising Cookies:</strong> Usually expire after 30 days to 2 years</li>
            </ul>

            <h2>Impact of Disabling Cookies</h2>
            <p>
              While you can disable cookies, doing so may affect your experience on our website:
            </p>
            <ul>
              <li>Some features may not work properly</li>
              <li>You may need to re-enter information</li>
              <li>Personalization features may be limited</li>
              <li>Analytics data may be incomplete</li>
            </ul>

            <h2>Updates to This Policy</h2>
            <p>
              We may update this Cookies Policy from time to time to reflect changes in our practices or applicable laws. We will notify you of any significant changes by posting the updated policy on our website.
            </p>

            <h2>Contact Us</h2>
            <p>
              If you have any questions about our use of cookies or this Cookies Policy, please contact us at:
            </p>
            <ul>
              <li>Email: privacy@tinylink.com</li>
              <li>Address: 123 Tech Street, San Francisco, CA 94105</li>
            </ul>
          </div>
        </div>
        
        <AdBanner position="bottom" />
      </main>
      
      <Footer />
    </div>
  );
}