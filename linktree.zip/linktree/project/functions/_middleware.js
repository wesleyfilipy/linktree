// Cloudflare Pages middleware for handling SQLite database in production
export async function onRequest(context) {
  // Get the incoming request
  const request = context.request;
  const url = new URL(request.url);
  
  // Continue with the normal request handling
  try {
    const response = await context.next();
    
    // Clone the response so we can modify headers
    const newResponse = new Response(response.body, response);
    
    // Add security headers
    newResponse.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
    newResponse.headers.set("X-Content-Type-Options", "nosniff");
    newResponse.headers.set("X-Frame-Options", "DENY");
    newResponse.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
    newResponse.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    newResponse.headers.set("Content-Security-Policy", "upgrade-insecure-requests");
    
    return newResponse;
  } catch (err) {
    // Handle errors gracefully, particularly if there are SQLite database issues
    return new Response(`Error processing request: ${err.message}`, { 
      status: 500,
      headers: {
        "Content-Type": "text/plain",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload"
      }
    });
  }
} 