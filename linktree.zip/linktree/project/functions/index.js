// Arquivo para configuração de funções do Cloudflare Pages
export function onRequest(context) {
  const response = context.next();
  
  // Configurações de segurança para SSL
  response.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("Content-Security-Policy", "upgrade-insecure-requests");
  
  return response;
} 