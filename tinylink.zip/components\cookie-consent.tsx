'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Cookie } from 'lucide-react';

export function CookieConsent() {
  const [showConsent, setShowConsent] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      setShowConsent(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setShowConsent(false);
  };

  const declineCookies = () => {
    localStorage.setItem('cookieConsent', 'declined');
    setShowConsent(false);
  };

  if (!showConsent) {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-sm mx-auto">
      <Card className="shadow-lg">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Cookie className="w-5 h-5 text-amber-600" />
              <CardTitle className="text-base">Cookie Consent</CardTitle>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={declineCookies}
              className="h-6 w-6"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <CardDescription className="text-sm mb-4">
            We use cookies to enhance your experience and show personalized ads. By continuing to use our site, you agree to our cookie policy.
          </CardDescription>
          <div className="flex space-x-2">
            <Button onClick={acceptCookies} size="sm" className="flex-1">
              Accept
            </Button>
            <Button onClick={declineCookies} variant="outline" size="sm" className="flex-1">
              Decline
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}