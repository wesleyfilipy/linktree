import { Metadata } from 'next';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { AdBanner } from '@/components/ad-banner';

export const metadata: Metadata = {
  title: 'Privacy Policy - TinyLink',
  description: 'Read our privacy policy to understand how we collect, use, and protect your information when using TinyLink URL shortener.',
};

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <AdBanner position="top" />
        
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
          
          <div className="prose prose-lg max-w-none dark:prose-invert">
            <p className="text-muted-foreground mb-8">
              <strong>Effective Date:</strong> January 1, 2024<br />
              <strong>Last Updated:</strong> January 1, 2024
            </p>

            <h2>Introduction</h2>
            <p>
              Welcome to TinyLink ("we," "our," or "us"). We are committed to protecting your privacy and ensuring you have a positive experience on our website and in using our URL shortening services. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our services.
            </p>

            <h2>Information We Collect</h2>
            
            <h3>Information You Provide to Us</h3>
            <ul>
              <li><strong>Account Information:</strong> If you create an account, we collect your email address and any other information you provide during registration.</li>
              <li><strong>URLs:</strong> We store the original URLs you submit for shortening.</li>
              <li><strong>Custom Slugs:</strong> Any custom slugs you create for your shortened URLs.</li>
              <li><strong>Contact Information:</strong> If you contact us, we collect your name, email address, and message content.</li>
            </ul>

            <h3>Information Automatically Collected</h3>
            <ul>
              <li><strong>Click Analytics:</strong> We track clicks on shortened URLs, including timestamp, IP address, referrer, and user agent.</li>
              <li><strong>Usage Data:</strong> Information about how you use our services, including pages visited and features used.</li>
              <li><strong>Device Information:</strong> Device type, operating system, and browser information.</li>
              <li><strong>Cookies:</strong> We use cookies and similar tracking technologies to enhance your experience.</li>
            </ul>

            <h2>How We Use Your Information</h2>
            <p>We use the information we collect to:</p>
            <ul>
              <li>Provide, maintain, and improve our URL shortening services</li>
              <li>Generate analytics and insights for your shortened URLs</li>
              <li>Communicate with you about your account or our services</li>
              <li>Detect and prevent fraud or abuse</li>
              <li>Comply with legal obligations</li>
              <li>Personalize your experience</li>
            </ul>

            <h2>Information Sharing and Disclosure</h2>
            <p>We do not sell, trade, or otherwise transfer your personal information to third parties, except in the following circumstances:</p>
            <ul>
              <li><strong>Service Providers:</strong> We may share information with trusted service providers who assist us in operating our services.</li>
              <li><strong>Legal Requirements:</strong> We may disclose information if required by law or in response to valid legal requests.</li>
              <li><strong>Business Transfers:</strong> In the event of a merger, acquisition, or sale of assets, your information may be transferred.</li>
              <li><strong>Consent:</strong> We may share information with your explicit consent.</li>
            </ul>

            <h2>Data Security</h2>
            <p>
              We implement appropriate technical and organizational measures to protect your information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure.
            </p>

            <h2>Your Rights and Choices</h2>
            <p>You have the right to:</p>
            <ul>
              <li>Access and review your personal information</li>
              <li>Request correction of inaccurate information</li>
              <li>Request deletion of your information</li>
              <li>Opt out of certain communications</li>
              <li>Disable cookies through your browser settings</li>
            </ul>

            <h2>International Data Transfers</h2>
            <p>
              Your information may be transferred to and processed in countries other than your country of residence. We ensure appropriate safeguards are in place to protect your information in accordance with this Privacy Policy.
            </p>

            <h2>Children's Privacy</h2>
            <p>
              Our services are not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13. If we become aware that we have collected personal information from a child under 13, we will take steps to delete such information.
            </p>

            <h2>Google AdSense</h2>
            <p>
              We use Google AdSense to display advertisements on our website. Google AdSense uses cookies to serve ads based on your prior visits to our website or other websites. You can opt out of personalized advertising by visiting Google's Ads Settings.
            </p>

            <h2>Changes to This Privacy Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
            </p>

            <h2>Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy or our privacy practices, please contact us at:
            </p>
            <ul>
              <li>Email: privacy@tinylink.com</li>
              <li>Address: 123 Tech Street, San Francisco, CA 94105</li>
            </ul>
          </div>
        </div>
        
        <AdBanner position="bottom" />
      </main>
      
      <Footer />
    </div>
  );
}