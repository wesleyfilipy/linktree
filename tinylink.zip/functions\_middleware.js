// Cloudflare Pages middleware for handling SQLite database in production
export async function onRequest(context) {
  // Get the incoming request
  const request = context.request;
  const url = new URL(request.url);
  
  // Continue with the normal request handling
  try {
    return await context.next();
  } catch (err) {
    // Handle errors gracefully, particularly if there are SQLite database issues
    return new Response(`Error processing request: ${err.message}`, { status: 500 });
  }
} 