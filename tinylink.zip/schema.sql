-- Schema for TinyLink database on Cloudflare D1

-- URLs table for storing shortened links
CREATE TABLE IF NOT EXISTS urls (
  slug TEXT PRIMARY KEY,
  originalUrl TEXT NOT NULL,
  clicks INTEGER DEFAULT 0,
  createdAt TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_urls_clicks ON urls (clicks DESC);
CREATE INDEX IF NOT EXISTS idx_urls_createdAt ON urls (createdAt DESC); 