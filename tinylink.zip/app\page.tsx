'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link as LinkIcon, Copy, QrCode, BarChart3, Zap, Shield, Globe } from 'lucide-react';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { AdBanner } from '@/components/ad-banner';
import { QRCodeGenerator } from '@/components/qr-code-generator';

export default function Home() {
  const [longUrl, setLongUrl] = useState('');
  const [customSlug, setCustomSlug] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleShortenUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!longUrl.trim()) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/shorten', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: longUrl, customSlug })
      });

      if (response.ok) {
        const data = await response.json();
        setShortUrl(data.shortUrl);
      } else {
        console.error('Failed to shorten URL');
      }
    } catch (error) {
      console.error('Error shortening URL:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async () => {
    if (shortUrl) {
      await navigator.clipboard.writeText(shortUrl);
    }
  };

  const features = [
    {
      icon: Link,
      title: 'URL Shortening',
      description: 'Transform long URLs into short, memorable links instantly'
    },
    {
      icon: BarChart3,
      title: 'Analytics',
      description: 'Track clicks, referrers, and geographic data for your links',
      link: '/analytics'
    },
    {
      icon: QrCode,
      title: 'QR Codes',
      description: 'Generate QR codes for easy mobile sharing'
    },
    {
      icon: Shield,
      title: 'Link Validation',
      description: 'Automatic protection against malicious and spam links'
    },
    {
      icon: Zap,
      title: 'Fast Redirects',
      description: 'Lightning-fast 301 redirects for optimal SEO'
    },
    {
      icon: Globe,
      title: 'Global CDN',
      description: 'Worldwide content delivery for maximum speed'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <AdBanner position="top" />
        
        {/* Hero Section */}
        <section className="text-center py-16">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Shorten URLs & Track Performance
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
              Create short, trackable links with detailed analytics. Perfect for social media, email campaigns, and marketing.
            </p>
            <Badge variant="secondary" className="mb-8">
              ✨ Free Forever • No Sign-up Required
            </Badge>
          </div>
        </section>

        {/* URL Shortener Form */}
        <section className="max-w-4xl mx-auto mb-16">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LinkIcon className="w-6 h-6" />
                URL Shortener
              </CardTitle>
              <CardDescription>
                Paste your long URL below and get a short, trackable link instantly
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleShortenUrl} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    type="url"
                    placeholder="Enter your long URL here..."
                    value={longUrl}
                    onChange={(e) => setLongUrl(e.target.value)}
                    required
                    className="col-span-full"
                  />
                  <Input
                    type="text"
                    placeholder="Custom slug (optional)"
                    value={customSlug}
                    onChange={(e) => setCustomSlug(e.target.value)}
                    className="md:col-span-1"
                  />
                  <Button type="submit" disabled={isLoading} className="md:col-span-1">
                    {isLoading ? 'Shortening...' : 'Shorten URL'}
                  </Button>
                </div>
                
                {shortUrl && (
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <p className="text-sm text-gray-600 dark:text-gray-300">Your short URL:</p>
                        <p className="font-mono text-lg text-green-700 dark:text-green-400">{shortUrl}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={copyToClipboard} variant="outline" size="sm">
                          <Copy className="w-4 h-4 mr-1" />
                          Copy
                        </Button>
                        <QRCodeGenerator url={shortUrl} />
                      </div>
                    </div>
                    <div className="mt-3 text-right">
                      <Link href="/analytics">
                        <Button variant="link" size="sm" className="text-blue-600 dark:text-blue-400">
                          <BarChart3 className="w-4 h-4 mr-1" />
                          Track Analytics
                        </Button>
                      </Link>
                    </div>
                  </div>
                )}
              </form>
            </CardContent>
          </Card>
        </section>

        <AdBanner position="middle" />

        {/* Features Section */}
        <section className="py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our URL Shortener?</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              More than just a URL shortener. Get detailed analytics, custom domains, and enterprise-grade features.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <feature.icon className="w-12 h-12 text-blue-600 mb-4" />
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">{feature.description}</p>
                  {feature.link && (
                    <Link href={feature.link}>
                      <Button variant="outline" size="sm" className="w-full">
                        View {feature.title}
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Trusted by Thousands</h2>
            <p className="text-gray-600 dark:text-gray-300">
              Join the growing community of users who trust our platform
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">10K+</div>
              <div className="text-gray-600 dark:text-gray-300">URLs Shortened</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 mb-2">5K+</div>
              <div className="text-gray-600 dark:text-gray-300">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">99.9%</div>
              <div className="text-gray-600 dark:text-gray-300">Uptime</div>
            </div>
          </div>
        </section>

        <AdBanner position="bottom" />
      </main>

      <Footer />
    </div>
  );
}