# Deployment Guide for TinyLink

This guide walks you through deploying TinyLink to GitHub and Cloudflare Pages.

## GitHub Deployment

1. **Create a GitHub Repository**

   Go to [GitHub](https://github.com) and create a new repository.

2. **Push Your Code to GitHub**

   ```bash
   # Initialize Git repository (if not already done)
   git init

   # Add all files to Git
   git add .

   # Commit the changes
   git commit -m "Initial commit"

   # Add GitHub repository as remote
   git remote add origin https://github.com/yourusername/tinylink.git

   # Push to GitHub
   git push -u origin main
   ```

## Cloudflare Pages Deployment

### Method 1: Direct Deployment via Cloudflare Dashboard

1. **Log in to Cloudflare Dashboard**

   Go to [Cloudflare Dashboard](https://dash.cloudflare.com/) and log in.

2. **Create a New Pages Project**

   - Click on "Pages" in the sidebar
   - Click "Create a project" > "Connect to Git"
   - Select your GitHub repository
   - If your repository isn't listed, you might need to configure the Cloudflare GitHub app

3. **Configure Build Settings**

   - **Project name**: `tinylink` (or your preferred name)
   - **Production branch**: `main`
   - **Framework preset**: Select "Next.js"
   - **Build command**: `npm run build`
   - **Build output directory**: `.next`
   - **Environment variables**:
     - Add `NODE_VERSION` with value `18`
     - Add `NEXT_PUBLIC_BASE_URL` with your domain (e.g., `https://tinylink.pages.dev`)

4. **Deploy**

   Click "Save and Deploy" to start the deployment process.

### Method 2: Deployment via GitHub Actions

1. **Configure GitHub Repository Secrets**

   In your GitHub repository:
   - Go to Settings > Secrets and variables > Actions
   - Add the following secrets:
     - `CLOUDFLARE_API_TOKEN`: Your Cloudflare API token with Pages permissions
     - `CLOUDFLARE_ACCOUNT_ID`: Your Cloudflare account ID

2. **Add Repository Variables**

   - Go to Settings > Secrets and variables > Actions > Variables tab
   - Add `NEXT_PUBLIC_BASE_URL` with your Cloudflare Pages domain

3. **Push Changes**

   The GitHub Actions workflow will automatically deploy your app to Cloudflare Pages when you push to the main branch.

## Database Considerations for Cloudflare

Since SQLite isn't natively supported in Cloudflare's serverless environment, we've provided alternative implementations:

### Option 1: In-memory Storage (Default)

The app will automatically use in-memory storage when deployed to Cloudflare Pages. This is suitable for testing but will not persist data between deployments.

### Option 2: Cloudflare D1 (Recommended for Production)

For persistent storage, you should use Cloudflare D1 database:

1. **Install Wrangler CLI**

   ```bash
   npm install -g wrangler
   ```

2. **Log in to Cloudflare**

   ```bash
   wrangler login
   ```

3. **Create a D1 Database**

   ```bash
   wrangler d1 create tinylink
   ```

4. **Update the wrangler.toml File**

   Uncomment and update the D1 database configuration with your database ID.

5. **Create the Database Schema**

   ```bash
   wrangler d1 execute tinylink --file=schema.sql
   ```

   Where `schema.sql` contains:
   ```sql
   CREATE TABLE urls (
     slug TEXT PRIMARY KEY,
     originalUrl TEXT NOT NULL,
     clicks INTEGER DEFAULT 0,
     createdAt TEXT DEFAULT CURRENT_TIMESTAMP
   );
   ```

6. **Update the Cloudflare-specific Database Implementation**

   Modify `lib/cloudflare-db.ts` to use D1 instead of in-memory storage.

## Custom Domain Setup

1. **Add a Custom Domain in Cloudflare Pages**

   - Go to your Pages project
   - Click on "Custom domains"
   - Click "Set up a custom domain"
   - Follow the instructions to add and verify your domain

2. **Update Environment Variables**

   After setting up your custom domain, update the `NEXT_PUBLIC_BASE_URL` environment variable to use your custom domain.

## Troubleshooting

- **Build Failures**: Check build logs in the Cloudflare Pages dashboard
- **API Errors**: Check Functions logs in the Cloudflare Pages dashboard
- **Database Issues**: Verify your D1 configuration in wrangler.toml

## Monitoring and Analytics

- Use Cloudflare Analytics for traffic monitoring
- Use Cloudflare Web Analytics for visitor insights
- The built-in analytics page of TinyLink shows link performance 