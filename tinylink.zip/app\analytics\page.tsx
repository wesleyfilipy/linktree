'use client';

import { useState, useEffect } from 'react';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, BarChart3, Clock, Link as LinkIcon } from 'lucide-react';

interface UrlData {
  slug: string;
  originalUrl: string;
  clicks: number;
  createdAt: string;
}

export default function Analytics() {
  const [urlData, setUrlData] = useState<UrlData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUrls = async () => {
      try {
        const response = await fetch('/api/analytics');
        if (response.ok) {
          const data = await response.json();
          setUrlData(data);
        }
      } catch (error) {
        console.error('Error fetching analytics data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUrls();
  }, []);

  const filteredData = urlData.filter((url) => 
    url.slug.includes(searchTerm) || url.originalUrl.includes(searchTerm)
  );

  function formatDate(dateString: string) {
    const date = new Date(dateString);
    return date.toLocaleString();
  }

  function truncateUrl(url: string, maxLength = 50) {
    return url.length > maxLength ? `${url.substring(0, maxLength)}...` : url;
  }

  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Link Analytics</h1>
        
        <div className="mb-8">
          <div className="flex gap-4 flex-wrap">
            <Card className="flex-1 min-w-[250px]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Links</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <LinkIcon className="mr-2 h-4 w-4 text-blue-600" />
                  <span className="text-2xl font-bold">{urlData.length}</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="flex-1 min-w-[250px]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Clicks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <BarChart3 className="mr-2 h-4 w-4 text-green-600" />
                  <span className="text-2xl font-bold">
                    {urlData.reduce((sum, item) => sum + item.clicks, 0)}
                  </span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="flex-1 min-w-[250px]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Most Popular Link</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4 text-purple-600" />
                  <span className="text-md font-medium truncate">
                    {urlData.length > 0 
                      ? urlData.sort((a, b) => b.clicks - a.clicks)[0]?.slug
                      : 'No links yet'}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <div className="flex items-center mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search links..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Short Link</TableHead>
                  <TableHead>Original URL</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Clicks</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      Loading analytics data...
                    </TableCell>
                  </TableRow>
                ) : filteredData.length > 0 ? (
                  filteredData.map((item) => (
                    <TableRow key={item.slug}>
                      <TableCell>
                        <a 
                          href={`${baseUrl}/${item.slug}`} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          {`${baseUrl}/${item.slug}`}
                        </a>
                      </TableCell>
                      <TableCell className="max-w-[300px] truncate" title={item.originalUrl}>
                        <a 
                          href={item.originalUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-gray-600 hover:underline"
                        >
                          {truncateUrl(item.originalUrl)}
                        </a>
                      </TableCell>
                      <TableCell>{formatDate(item.createdAt)}</TableCell>
                      <TableCell className="font-medium">{item.clicks}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      No links found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
} 