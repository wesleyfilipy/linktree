import { notFound, redirect } from 'next/navigation';
import { InterstitialPage } from '@/components/interstitial-page';
import { getUrlBySlug, incrementClicks } from '@/lib/db-adapter';

interface PageProps {
  params: { slug: string };
  searchParams: { [key: string]: string | string[] | undefined };
}

async function getUrlData(slug: string) {
  // Get URL data directly from the database
  const urlData = getUrlBySlug(slug);
  
  if (!urlData) {
    return null;
  }
  
  // Increment click count
  incrementClicks(slug);
  
  return urlData;
}

export default async function RedirectPage({ params, searchParams }: PageProps) {
  const { slug } = params;
  const urlData = await getUrlData(slug);

  if (!urlData) {
    notFound();
  }

  const showInterstitial = searchParams.interstitial !== 'false';

  if (showInterstitial) {
    return <InterstitialPage url={urlData.originalUrl} />;
  }

  // Direct redirect
  redirect(urlData.originalUrl);
}