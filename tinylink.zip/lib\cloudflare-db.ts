// This file provides alternative database functionality for Cloudflare Pages
// Since SQLite doesn't work natively on Cloudflare Pages, we'll use D1 or KV when deployed
// For local development, we'll continue using the SQLite implementation

// Interface matching our database functions
export interface UrlStorage {
  storeUrl: (slug: string, url: string) => void;
  getUrlBySlug: (slug: string) => any;
  incrementClicks: (slug: string) => void;
  slugExists: (slug: string) => boolean;
  getAllUrls: () => any[];
}

// In-memory fallback for Cloudflare environment
class InMemoryStorage implements UrlStorage {
  private urls: Map<string, { originalUrl: string; clicks: number; createdAt: string }> = new Map();

  storeUrl(slug: string, url: string) {
    this.urls.set(slug, {
      originalUrl: url,
      clicks: 0,
      createdAt: new Date().toISOString(),
    });
  }

  getUrlBySlug(slug: string) {
    const data = this.urls.get(slug);
    if (!data) return null;
    return { slug, ...data };
  }

  incrementClicks(slug: string) {
    const data = this.urls.get(slug);
    if (data) {
      this.urls.set(slug, {
        ...data,
        clicks: data.clicks + 1,
      });
    }
  }

  slugExists(slug: string) {
    return this.urls.has(slug);
  }

  getAllUrls() {
    return Array.from(this.urls.entries()).map(([slug, data]) => ({
      slug,
      ...data,
    }));
  }
}

// Factory function to get the appropriate storage implementation based on environment
export function getDbImplementation(): UrlStorage {
  // For now, we'll use the in-memory implementation for Cloudflare
  // In a real production app, you would integrate with Cloudflare D1 or KV here
  return new InMemoryStorage();
}

// Note: When deploying to Cloudflare Pages, you'll want to:
// 1. Import and use this database implementation instead of the SQLite one
// 2. Set up appropriate Cloudflare Workers KV namespaces or D1 databases
// 3. Modify the implementation to use those Cloudflare-specific storage solutions 