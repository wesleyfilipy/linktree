import { NextRequest, NextResponse } from 'next/server';
import { getAllUrls } from '@/lib/db-adapter';

export async function GET(request: NextRequest) {
  try {
    const urls = getAllUrls();
    
    return NextResponse.json(urls);
  } catch (error) {
    console.error('Error fetching analytics data:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 