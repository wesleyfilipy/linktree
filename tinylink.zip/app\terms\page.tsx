import { Metadata } from 'next';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { AdBanner } from '@/components/ad-banner';

export const metadata: Metadata = {
  title: 'Terms of Service - TinyLink',
  description: 'Read our terms of service to understand the rules and guidelines for using TinyLink URL shortener.',
};

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <AdBanner position="top" />
        
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
          
          <div className="prose prose-lg max-w-none dark:prose-invert">
            <p className="text-muted-foreground mb-8">
              <strong>Effective Date:</strong> January 1, 2024<br />
              <strong>Last Updated:</strong> January 1, 2024
            </p>

            <h2>Agreement to Terms</h2>
            <p>
              By accessing and using TinyLink ("we," "our," or "us"), you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
            </p>

            <h2>Use License</h2>
            <p>
              Permission is granted to temporarily use TinyLink for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
            </p>
            <ul>
              <li>Modify or copy the materials</li>
              <li>Use the materials for any commercial purpose or for any public display</li>
              <li>Attempt to reverse engineer any software contained on TinyLink</li>
              <li>Remove any copyright or other proprietary notations from the materials</li>
            </ul>

            <h2>Prohibited Uses</h2>
            <p>You may not use our service:</p>
            <ul>
              <li>For any unlawful purpose or to solicit others to unlawful acts</li>
              <li>To violate any international, federal, provincial, or state regulations, rules, laws, or local ordinances</li>
              <li>To infringe upon or violate our intellectual property rights or the intellectual property rights of others</li>
              <li>To harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate</li>
              <li>To submit false or misleading information</li>
              <li>To upload or transmit viruses or any other type of malicious code</li>
              <li>To collect or track the personal information of others</li>
              <li>To spam, phish, pharm, pretext, spider, crawl, or scrape</li>
              <li>For any obscene or immoral purpose</li>
              <li>To interfere with or circumvent the security features of our service</li>
            </ul>

            <h2>URL Content Restrictions</h2>
            <p>You agree not to use our service to shorten URLs that:</p>
            <ul>
              <li>Link to illegal content</li>
              <li>Contain malware, viruses, or other harmful software</li>
              <li>Are used for phishing or fraudulent activities</li>
              <li>Link to adult content or pornography</li>
              <li>Violate intellectual property rights</li>
              <li>Are used for spam or unsolicited communications</li>
              <li>Link to hate speech or discriminatory content</li>
            </ul>

            <h2>Service Availability</h2>
            <p>
              We strive to provide reliable service but do not guarantee 100% uptime. We reserve the right to modify, suspend, or discontinue any part of our service at any time without notice.
            </p>

            <h2>Data and Analytics</h2>
            <p>
              We collect analytics data on shortened URLs including click counts, geographic information, and referrer data. This data is used to provide analytics to users and improve our service.
            </p>

            <h2>Account Termination</h2>
            <p>
              We reserve the right to terminate or suspend your account and access to our service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
            </p>

            <h2>Disclaimer</h2>
            <p>
              The information on this website is provided on an "as is" basis. To the fullest extent permitted by law, this Company:
            </p>
            <ul>
              <li>Excludes all representations and warranties relating to this website and its contents</li>
              <li>Excludes all liability for damages arising out of or in connection with your use of this website</li>
            </ul>

            <h2>Limitations of Liability</h2>
            <p>
              In no event shall TinyLink or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the service, even if TinyLink or its authorized representative has been notified orally or in writing of the possibility of such damage.
            </p>

            <h2>Accuracy of Materials</h2>
            <p>
              The materials appearing on TinyLink could include technical, typographical, or photographic errors. TinyLink does not warrant that any of the materials on its website are accurate, complete, or current.
            </p>

            <h2>Links</h2>
            <p>
              TinyLink has not reviewed all of the sites linked to our website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by TinyLink of the site. Use of any such linked website is at the user's own risk.
            </p>

            <h2>Modifications</h2>
            <p>
              TinyLink may revise these terms of service for its website at any time without notice. By using this website, you are agreeing to be bound by the then current version of these terms of service.
            </p>

            <h2>Governing Law</h2>
            <p>
              These terms and conditions are governed by and construed in accordance with the laws of the United States and you irrevocably submit to the exclusive jurisdiction of the courts in that state or location.
            </p>

            <h2>Contact Information</h2>
            <p>
              If you have any questions about these Terms of Service, please contact us at:
            </p>
            <ul>
              <li>Email: legal@tinylink.com</li>
              <li>Address: 123 Tech Street, San Francisco, CA 94105</li>
            </ul>
          </div>
        </div>
        
        <AdBanner position="bottom" />
      </main>
      
      <Footer />
    </div>
  );
}